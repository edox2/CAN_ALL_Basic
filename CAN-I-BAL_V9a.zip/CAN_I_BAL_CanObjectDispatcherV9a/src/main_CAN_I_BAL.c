
#include <SI_C8051F550_Defs.h>
#include <SI_C8051F550_Register_Enums.h>
#include <STRING.h>
#include "I2cDispatcher.h"
#include "HalDef.h"


//-----------------------------------------------------------------------------
// Type Definitions
//-----------------------------------------------------------------------------


typedef union SI_UU64
{
  uint32_t u32[2];
  uint16_t u16[4];
  uint8_t u8[8];
} SI_UU64_t;


//-----------------------------------------------------------------------------
// Function Prototypes
//-----------------------------------------------------------------------------

void OSCILLATOR_Init (void);
void PORT_Init (void);
void TIMER0_Init(void);
void ADC_Init (void);


void OutAset(uint8_t PwmDutyCycleA);
void OutBset(uint8_t PwmDutyCycleB);

uint16_t getAdcReading(uint8_t pin);
uint16_t SetGaugeHiRes(uint8_t Channel, float SetValuePerMille, float MinResistance, float MaxResistance, uint8_t Step);

uint16_t SetGaugeSmooth(uint8_t Channel, float SetValuePerMille, float MinResistance, float MaxResistance, uint8_t Step);
uint16_t GetGaugeVoltageAtCurrent(uint8_t Channel, float SetValuePerMille, float MinCurrent, float MaxCurrent);
uint16_t SetGauge(uint8_t Channel, float SetValuePerMille, float MinResistance, float MaxResistance);

//REF0CN    = 0x38;
void CANinit (void);
void CANsetupMessageObj(uint8_t objNum, uint16_t canId, uint8_t dirTx,  uint8_t len, SI_UU64_t payload);
void CANtransferMessageObj(uint8_t objNum, SI_UU64_t payload);
void CANtriggerMessageObj(uint8_t objNum);
SI_UU64_t CANgetMessageObjPayload(uint8_t objNum);
int16_t CANgetMessageInt(uint8_t objNum, uint8_t startIndex);
//SI_UU64_t CANgetMessageObj(uint8_t objNum, uint16_t *canId, uint8_t *dirTx,  uint8_t *len, SI_UU64_t payload);

uint16_t GaugeScaleConverter (uint16_t permillage);
uint16_t TempToPermilleScaleConverter(int16_t TempValue);


SI_INTERRUPT_PROTO(CAN0_ISR, INTERRUPT_CAN0);
SI_INTERRUPT_PROTO(TIMER0_ISR, INTERRUPT_TIMER0);

//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------

#define CHANNEL_GAUGE_A (0)
#define CHANNEL_GAUGE_B (1)

#define MAX_RES (240.0F) //1kOhm
#define MIN_RES (33.0F) //0Ohm

#define FUEL_WARN_LEVEL (150) // Lit Warn-Lamp at Battery-level below 15%

#define MAX_CURRENT (56e-3F) //56mA
#define MIN_CURRENT (20e-3F) //15mA

#define VoltageK (2.256e-3F)   //1 Digit of ADC corresponds to 2.256mV (Attenuator = 12kOhms:4.7kOhm Ref = Vdd = 2.6V)
#define CurrentK (653.59e-6F)  //1 digit of DAC corresponds to 653.59uA

#define SYSCLK         (24000000)        // System clock speed in Hz

#define POLLRATE_HZ          (20)        // Timer Frequency in Hz.

// Minimum value is 1 (battery needs min. 10Hz)
#define STARTUP_DELAY        (10)        // POLLRATE_HZ /s * STARTUP_DELAY
                                       
#define MESSAGE_OBJECTS      (33)        // Number of message objects to use
                                       // Range is 1-32 + 1 Dummy 0 + 32 is same

#define TX_COMPLETE_MASK  (0xFFFFFFFF)   // Set this to (2^MESSAGE_OBJECTS - 1)

#define NUM_OF_BATTERIES (0)            // Minimal amount of batteries in use

// Reload value for Timer0 assuming a 1:48 scaling factor for Timer0 clock
#define TIMER0_RL_HIGH  (0xFFFF -((SYSCLK/48/POLLRATE_HZ >> 8) & 0x00FF))
#define TIMER0_RL_LOW   (0xFFFF -(SYSCLK/48/POLLRATE_HZ & 0x00FF))

#define SEND_HEARTBEAT (1)
#define SEND_DBG_COUNTER (1)

// CAN-Ids for Message Objects.

#define CAN_ID_BROADCAST   (0x000)
#define CAN_ID_HEARTBEAT   (0x700) // Test Message of this device
#define CAN_ALL_ID         (0x01B) // Test Message of this device

#define CAN_ID_TEMP   (0x400)

#define CAN_ID_INVERTER     (0x001) // CAN-ID of Inverter device
#define CAN_ID_BAT1         (0x006) // CAN-ID of Battery 1 BMS
#define CAN_ID_BAT2         (0x007) // CAN-ID of Battery 2 BMS
#define CAN_ID_BAT3         (0x008) // CAN-ID of Battery 3 BMS
#define CAN_ID_BAT4         (0x009) // CAN-ID of Battery 4 BMS
#define CAN_ID_IMD_REQUEST  (0x022) // CAN-ID of Isolation Monitor Request
#define CAN_ID_IMD_RESPONSE (0x023) // CAN-ID of Isolation Monitor Response
#define CAN_ID_IMD_INFO     (0x037) // CAN-ID of Isolation Monitor Info-Message

// Contents of message
#define BMS_BAT_ON          (0x01)
#define BMS_BAT_OFF         (0x00)
#define BMS_BAT_CH          (0x02)
#define BMS_STATE_VALID_VALUES (0x0004)
#define BMS_STATE_NODE_ACTIVE  (0x0001)

//-----------------------------------------------------------------------------
// Bit Definition Masks
//-----------------------------------------------------------------------------

// CAN0STAT
#define BOff  (0x80)                     // Busoff Status
#define EWarn (0x40)                     // Warning Status
#define EPass (0x20)                     // Error Passive
#define RxOk  (0x10)                     // Receive Message Successfully
#define TxOk  (0x08)                     // Transmitted Message Successfully
#define LEC   (0x07)                     // Last Error Code

//-----------------------------------------------------------------------------
// Pin Definitions
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------

#define NOTCH_COUNT  (20)                     // Busoff Status
#define SMB_NUM_BYTES_READ (24)
int8_t Notch = 0;
const uint8_t RedLine[NOTCH_COUNT] =    {255, 219, 182, 145, 109,  73,  36,   0,   0,   0,   0,   0,   0,   0,  36,  73, 109, 146, 182, 219};
const uint8_t GreenLine[NOTCH_COUNT] =  {  0,   0,   0,   0,   0,   0,   0,  36,  73, 109, 146, 182, 219, 255, 219, 182, 145, 109,  73,  36};
const uint8_t BlueLine[NOTCH_COUNT] =   {  0,  36,  73, 109, 146, 182, 219, 255, 219, 182, 145, 109,  73,  36,   0,   0,   0,   0,   0,   0};
uint8_t DataArrayRead[24];
uint8_t DataArrayWrite[4];
uint8_t DataArray[SMB_NUM_BYTES_READ];
//static uint8_t xdata OutStr[TX_PACKET_SIZE];     // Packet to transmit to host

float Permillage = 0.0F;
uint8_t CalibStep = 0;
uint8_t KeyCounter = 0x00;
int8_t LastNotch = 0;
uint8_t ButtonState = 0;
uint8_t SwitchDirection = 0;
int8_t SwitchDirectionX = 0;
int8_t SwitchDirectionY = 0;
uint8_t Segment = 0;
uint8_t Red = 255;
uint8_t Green = 0;
uint8_t Blue = 0;
uint8_t MixColor = 0;
uint8_t WorkColor = 0;
uint8_t Intensity = 0;
bool up = false;
bool down = false;
const int8_t MaxNotch = NOTCH_COUNT;
int8_t DeltaNotch = 0;
int16_t Gain = 0;
bool RainbowMode = true;
volatile uint8_t Angle;
volatile uint8_t Supply;
volatile int8_t TempBase;
volatile int8_t TempHandle;
volatile uint8_t Version;
volatile uint8_t serialNo[16];
SI_UU64_t TempPayload;

uint8_t PwmOutA = 0;
uint8_t PwmOutB = 0;
uint8_t PeakNumOfBat = 0;

bit CAN_ERROR = 0;                     // 0 = No Errors during transmission
                                       // 1 = Some error(s) occurred

SI_UU32_t CAN_RXTX_COMPLETE;           // Bit status register that is updated
                                       // when a RX or TX is complete is received for
                                       // a specific message object.  Should be
                                       // equal to TX_COMPLETE_MASK when done

SI_UU64_t LastBroadcastMsg;                // TempData to define CAN-Messages


uint8_t DebugInput = 0;

uint16_t Battery1SoC;
uint16_t Battery1SoH;
uint16_t Battery2SoC;
uint16_t Battery2SoH;
uint16_t Battery3SoC;
uint16_t Battery3SoH;
uint16_t Battery4SoC;
uint16_t Battery4SoH;
uint16_t BatterySoC;
uint16_t BatterySoH;

 int8_t InvInverter1Temp;
 int8_t InvMotor1Temp;
 SI_UU16_t InvMotor1Torque;
 SI_UU16_t InvMotorsFlags;
 SI_UU16_t InvSystemFlags;
 SI_UU16_t InvTimeToService_h;
 uint8_t InvTimeToService_min;
 uint8_t InvTimeToService_s;
 uint8_t InvFaultCode;
 uint8_t InvFaultLevel;
 SI_UU16_t InvDcBusCurrent_dA;

int16_t Battery1Current;
int16_t Battery2Current;
int16_t Battery3Current;
int16_t Battery4Current;
int16_t Battery1MaxChargeCurrent;
int16_t Battery2MaxChargeCurrent;
int16_t Battery3MaxChargeCurrent;
int16_t Battery4MaxChargeCurrent;
uint16_t Battery1CellDiff_mV;
uint16_t Battery2CellDiff_mV;
uint16_t Battery3CellDiff_mV;
uint16_t Battery4CellDiff_mV;
uint16_t IsoImcRiso_kOhm;
uint16_t IsoImcStatus;
uint16_t IsoVifcStatus;

#define BAT_CH   (0x02)
#define BAT_ON   (0x01)
#define BAT_OFF  (0x00)

#define TPDO1_INV     0x200
#define TPDO2_INV     0x201

#define TPDO1_BMS     0x1E0
#define TPDO2_BMS     0x2E0
#define TPDO3_BMS     0x3E0
#define TPDO4_BMS     0x4E0
#define RPDO1_BMS     0x200

#define CAN_DIR_TX    0x01
#define CAN_DIR_RX    0x00

#define SET_BAT1_STATE (1)  // Message Object to transmit State Msg to BAT1
#define SET_BAT2_STATE (2)  // Message Object to transmit State Msg to BAT2
#define SET_BAT3_STATE (3)  // Message Object to transmit State Msg to BAT3
#define SET_BAT4_STATE (4)  // Message Object to transmit State Msg to BAT4

#define GET_BAT1_STATE (5)  // Message Object to receive State Msg from BAT1
#define GET_BAT2_STATE (6)  // Message Object to receive State Msg from BAT2
#define GET_BAT3_STATE (7)  // Message Object to receive State Msg from BAT3
#define GET_BAT4_STATE (8)  // Message Object to receive State Msg from BAT4

#define SET_BROADCAST  (9)  // Message Object to transmit Broadcast such as <Start All Nodes>
#define SET_HEARTBEAT (10)  // Message Object to transmit Heartbeat or Startup Message to the CAN-BUS
#define GET_DEBUG_IN  (11)  // Message Object to receive Commands to this Module
#define SET_DEBUG_OUT (12)  // Message Object to transmit Commands to this Module

#define XET_DUMMY_13  (13)  // Message Object to
#define XET_DUMMY_14  (14)  // Message Object to
#define XET_DUMMY_15  (15)  // Message Object to
#define XET_DUMMY_16  (16)  // Message Object to

#define GET_INV_STATE1 (17)  // Message Object to receive first State Msg from INVERTER
#define GET_INV_STATE2 (18)  // Message Object to receive second State Msg from INVERTER
#define GET_IMD_INFO   (19)  // Message Object to receive Isolation Monitor Device Information
#define XET_DUMMY_20   (20)  // Message Object to

#define GET_BAT1_CURRENT  (21)  // Message Object to TPDO3 of BMS from BAT1
#define GET_BAT2_CURRENT  (22)  // Message Object to TPDO3 of BMS from BAT2
#define GET_BAT3_CURRENT  (23)  // Message Object to TPDO3 of BMS from BAT3
#define GET_BAT4_CURRENT  (24)  // Message Object to TPDO3 of BMS from BAT4

#define XET_DUMMY_25  (25)  // Message Object to
#define XET_DUMMY_26  (26)  // Message Object to
#define XET_DUMMY_27  (27)  // Message Object to
#define XET_DUMMY_28  (28)  // Message Object to

#define XET_DUMMY_29  (29)  // Message Object to
#define XET_DUMMY_30  (30)  // Message Object to
#define XET_DUMMY_32  (31)  // Message Object to
#define GET_BROADCAST (32)  // Message Object to get all the stuff not covered by other Message objects

volatile SI_UU64_t CanMsgObject[MESSAGE_OBJECTS];
volatile uint16_t CanMsgId[MESSAGE_OBJECTS];

static const uint16_t MessageBoxCanId[MESSAGE_OBJECTS] = // List of all CAN IDs associated to the CAN-objects
{
    CAN_ID_BROADCAST, // Dummy Line MsgObj0
    (RPDO1_BMS + CAN_ID_BAT1), (RPDO1_BMS + CAN_ID_BAT2), (RPDO1_BMS + CAN_ID_BAT3), (RPDO1_BMS + CAN_ID_BAT4), (TPDO1_BMS + CAN_ID_BAT1), (TPDO1_BMS + CAN_ID_BAT2), (TPDO1_BMS + CAN_ID_BAT3), (TPDO1_BMS + CAN_ID_BAT4),  //line 1-8
    (CAN_ID_BROADCAST), (CAN_ID_HEARTBEAT + CAN_ALL_ID), (CAN_ALL_ID), (CAN_ALL_ID), 0x013, 0x014, 0x015, 0x016,  //line 9-16
    (CAN_ID_INVERTER + TPDO1_INV), (CAN_ID_INVERTER + TPDO2_INV),  (CAN_ID_IMD_INFO), 0x020, (TPDO1_BMS + CAN_ID_BAT1), (TPDO3_BMS + CAN_ID_BAT2), (TPDO3_BMS + CAN_ID_BAT3), (TPDO3_BMS + CAN_ID_BAT4), //line 17-24
    0x025, 0x026, 0x027, 0x028, 0x029, 0x030, 0x031, CAN_ID_BROADCAST,  //line 25-32
};

static const uint8_t MessageBoxDirTx[MESSAGE_OBJECTS] = // List of all directions associated to the CAN-objects
{
    CAN_DIR_RX, // Dummy Line MsgObj0
    CAN_DIR_TX, CAN_DIR_TX, CAN_DIR_TX, CAN_DIR_TX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX,  //line 1-8
    CAN_DIR_TX, CAN_DIR_TX, CAN_DIR_RX, CAN_DIR_TX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX,  //line 9-16
    CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX,  //line 17-24
    CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX, CAN_DIR_RX,  //line 25-32
};

static const uint8_t MessageBoxSize[MESSAGE_OBJECTS] = // List of all sizes of all active CAN-objects 0-7
{
    8,// Dummy Line MsgObj0 Copy of 32!
    8, 8, 8, 8, 8, 8, 8, 8,   //line 1-8
    2, 1, 1, 2, 0, 0, 0, 0,   //line 9-16
    8, 8, 6, 0, 8, 8, 8, 8,   //line 17-24
    0, 0, 0, 0, 0, 0, 0, 8,   //line 25-32
};

static const uint8_t MessageBoxInUse[MESSAGE_OBJECTS] = // List of all active CAN-objects
{
    1,  // Dummy Line MsgObj0 Copy of 32!
    1, 1, 1, 1, 1, 1, 1, 1,   //line 1-8
    1, 1, 1, 1, 0, 0, 0, 0,   //line 9-16
    1, 1, 1, 0, 1, 1, 1, 1,   //line 17-24
    0, 0, 0, 0, 0, 0, 0, 1,   //line 25-32
};

uint16_t TempToPermilleScaleConverter(int16_t TempValue)
{
  //#define LUT_TAP_COUNT (10)
  #define TAB_RES int16_t
  #define TAB_IN (0)
  #define TAB_OUT (1)

    static const int16_t xdata LookUpTable[][TAB_OUT+1] = {
      {-40,   0},   // -40°C is lowest point on gauge
      {0, 250 },    // 0°C is 25% deflection of full scale
      {70, 500 },   // +70°C is half scale
      {120, 750 },  // +120° is 75% of full scale
      {127, 1000},  // +127C° is maximum value that comes from signal and corresponds to full scale therefore
    };


  // How to build up a conversion LookUpTable:
 // 1.) send out a known tap-value (expected-permillage) to gauge (without using this function) and read out finger position on gauge
 // 2.) add a line with a value-pair in the list above in the following from : {expected-permillage, finger-permillage},
 // 3.) keep list sorted: with lowest "expected-permillage" as first entry in first line. (For the second value "finger-permillage" both directions are possible
 // 4.) Important: Avoid ambiguity the the projection!
  TAB_RES tap = 0;
  TAB_RES LutTapCount = sizeof(LookUpTable) / (2 * sizeof(TAB_RES));
  float interpos = 0;
  for (tap = 0; tap < LutTapCount; tap++)
  {
      if (TempValue <= LookUpTable[tap][TAB_IN])
      {
         break;
      }
  }
  if (tap && LutTapCount > tap)
  {
      interpos = (float)(TempValue - LookUpTable[tap-1][TAB_IN]) / (float)(LookUpTable[tap][TAB_IN] - LookUpTable[tap-1][TAB_IN]);
      if (LookUpTable[tap][TAB_OUT] > LookUpTable[tap-1][TAB_OUT])
      {
         interpos = LookUpTable[tap-1][TAB_OUT] + interpos * (float)(LookUpTable[tap][TAB_OUT] - LookUpTable[tap-1][TAB_OUT]);

      }
      else
      {
         interpos = LookUpTable[tap-1][TAB_OUT] - interpos * (float)(LookUpTable[tap-1][TAB_OUT] - LookUpTable[tap][TAB_OUT]);
      }
  }
  else
  {
      if (LutTapCount > tap)
      {
         interpos = LookUpTable[tap][TAB_OUT];
      }
  }
  return (uint16_t)interpos;
}

  uint16_t GaugeScaleConverter(uint16_t permillage)
  {
  //#define LUT_TAP_COUNT (10)
  #define LUT_RES uint16_t
  #define LUT_IN (0)
  #define LUT_OUT (1)

    static const uint16_t xdata LookUpTable[][LUT_OUT+1] = {
      {0,   1000},
      {250, 640 },
      {500, 360 },
      {750, 200 },
      {1000, 0},
    };


  // How to build up a conversion LookUpTable:
 // 1.) send out a known tap-value (expected-permillage) to gauge (without using this function) and read out finger position on gauge
 // 2.) add a line with a value-pair in the list above in the following from : {expected-permillage, finger-permillage},
 // 3.) keep list sorted: with lowest "expected-permillage" as first entry in first line. (For the second value "finger-permillage" both directions are possible
 // 4.) Important: Avoid ambiguity the the projection!
  LUT_RES tap = 0;
  LUT_RES LutTapCount = sizeof(LookUpTable) / (2 * sizeof(LUT_RES));
  float interpos = 0;
  for (tap = 0; tap < LutTapCount; tap++)
  {
      if (permillage <= LookUpTable[tap][LUT_IN])
      {
         break;
      }
  }
  if (tap && LutTapCount > tap)
  {
      interpos = (float)(permillage - LookUpTable[tap-1][LUT_IN]) / (float)(LookUpTable[tap][LUT_IN] - LookUpTable[tap-1][LUT_IN]);
      if (LookUpTable[tap][LUT_OUT] > LookUpTable[tap-1][LUT_OUT])
      {
         interpos = LookUpTable[tap-1][LUT_OUT] + interpos * (float)(LookUpTable[tap][LUT_OUT] - LookUpTable[tap-1][LUT_OUT]);

      }
      else
      {
         interpos = LookUpTable[tap-1][LUT_OUT] - interpos * (float)(LookUpTable[tap-1][LUT_OUT] - LookUpTable[tap][LUT_OUT]);
      }
  }
  else
  {
      if (LutTapCount > tap)
      {
         interpos = LookUpTable[tap][LUT_OUT];
      }
  }
  return (uint16_t)interpos;
}


uint16_t GetGaugeVoltageAtCurrent(uint8_t Channel, float SetValuePerMille, float MinCurrent, float MaxCurrent)
{
  static float Voltage[2] = {0.0F, 0.0F};
  static float Current[2] = {0.0F, 0.0F};
  uint16_t DacValue;

  Current[Channel] = MinCurrent + (SetValuePerMille / 1000.0) * (MaxCurrent - MinCurrent);

  DacValue = Current[Channel] / CurrentK;
  DacValue &= 0x00ff;
  DataArrayWrite[0] = DacValue >> 4;
  DataArrayWrite[1] = DacValue << 4;
  AccessI2C(I2C_Channel_Monitor, 0x98 + Channel * 2 , 2, &DataArrayWrite, 0, &DataArrayRead, I2C_MODE_MULTIPLE_START);
  Voltage[Channel] = VoltageK * (float)(getAdcReading(0x0c + Channel));
  return Voltage[Channel];
}

uint16_t SetGauge(uint8_t Channel, float SetValuePerMille, float MinResistance, float MaxResistance)
{
//#define VoltageK (2.256e-3F)   //1 Digit of ADC corresponds to 2.256mV (Attenuator = 12kOhms:4.7kOhm Ref = Vdd = 2.6V)
//#define CurrentK (653.59e-6F)  //1 digit of DAC corresponds to 653.59uA
//#define ResistanceK  (0.1F)
//  static uint8_t[2] LastValue = 128;
//  static uint8_t[2] LastCurrent = 0;
  static float Voltage[2] = {0.0F, 0.0F};
  static float Current[2] = {0.0F, 0.0F};
  static float Resistance[2] = {0.0F, 0.0F};
  uint16_t DacValue;

  Resistance[Channel] = MinResistance + (SetValuePerMille / 1000.0) * (MaxResistance - MinResistance);
  Voltage[Channel] = VoltageK * (float)(getAdcReading(0x0c + Channel));
  Current[Channel] = Voltage[Channel] / Resistance[Channel];

  DacValue = Current[Channel] / CurrentK;
  DacValue &= 0x00ff;
  DataArrayWrite[0] = DacValue >> 4;
  DataArrayWrite[1] = DacValue << 4;
  AccessI2C(I2C_Channel_Monitor, 0x98 + Channel * 2 , 2/*NUM_BYTES_TO_WRITE*/, &DataArrayWrite, 0/*NUM_BYTES_TO_READ*/, &DataArrayRead, I2C_MODE_MULTIPLE_START);
  Voltage[Channel] = VoltageK * (float)(getAdcReading(0x0c + Channel));
  return (Resistance[Channel] / ((MaxResistance - MinResistance) / (Voltage[Channel] / Current[Channel])));
}


uint16_t SetGaugeHiRes(uint8_t Channel, float SetValuePerMille, float MinResistance, float MaxResistance, uint8_t Step)
{
#define VoltageK_HR (2.256e-3F)   //1 Digit of ADC corresponds to 2.256mV (Attenuator = 12kOhms:4.7kOhm Ref = Vdd = 2.6V)
#define CurrentK_HR (331.8e-6F)  //1 digit of DAC corresponds to 331.8e-6F (10.0Ohm Shunt and Voltage-Divider of 82k / 12k + 4.7k instead of full 5V from DAC)
   uint16_t DacValue;
  static uint16_t LastDacValue[2] = {0, 0};

  DacValue =((VoltageK_HR * (float)(getAdcReading(0x0c + Channel))) / (MinResistance + (SetValuePerMille / 1000.0) * (MaxResistance - MinResistance))) / 331.8e-6F;
  if (DacValue > LastDacValue[Channel])
    {
        DacValue = ((LastDacValue[Channel] + Step) > LastDacValue[Channel]) ? (LastDacValue[Channel] + Step) : 0xff;
    }
  else
    {
    if (DacValue < LastDacValue[Channel])
      {
        DacValue = ((LastDacValue[Channel] - Step) < LastDacValue[Channel]) ? (LastDacValue[Channel] - Step) : 0x00;
      }
    }
  LastDacValue[Channel] = DacValue;

  DacValue &= 0x00ff;  // Mask out Power-Mode Bits of DAC-Command
  DataArrayWrite[0] = DacValue >> 4; // Prepare Command
  DataArrayWrite[1] = DacValue << 4; // and Value for DAC
  AccessI2C(I2C_Channel_Monitor, 0x98 + Channel * 2 , 2, &DataArrayWrite, 0, &DataArrayRead, I2C_MODE_MULTIPLE_START);
  return (VoltageK_HR * (float)(getAdcReading(0x0c + Channel))) / ((float)DacValue * CurrentK_HR);
}

uint16_t SetGaugeSmooth(uint8_t Channel, float SetValuePerMille, float MinResistance, float MaxResistance, uint8_t Step)
{
  uint16_t DacValue;
  static uint16_t LastDacValue[2] = {0, 0};

  DacValue =((VoltageK * (float)(getAdcReading(0x0c + Channel))) / (MinResistance + (SetValuePerMille / 1000.0) * (MaxResistance - MinResistance))) / CurrentK;
  if (DacValue > LastDacValue[Channel])
    {
        DacValue = ((LastDacValue[Channel] + Step) > LastDacValue[Channel]) ? (LastDacValue[Channel] + Step) : 0xff;
    }
  else
    {
    if (DacValue < LastDacValue[Channel])
      {
        DacValue = ((LastDacValue[Channel] - Step) < LastDacValue[Channel]) ? (LastDacValue[Channel] - Step) : 0x00;
      }
    }
  LastDacValue[Channel] = DacValue;

  DacValue &= 0x00ff;  // Mask out Power-Mode Bits of DAC-Command
  DataArrayWrite[0] = DacValue >> 4; // Prepare Command
  DataArrayWrite[1] = DacValue << 4; // and Value for DAC
  AccessI2C(I2C_Channel_Monitor, 0x98 + Channel * 2 , 2, &DataArrayWrite, 0, &DataArrayRead, I2C_MODE_MULTIPLE_START);
  return (VoltageK * (float)(getAdcReading(0x0c + Channel))) / ((float)DacValue * CurrentK);
}

void OutAset(uint8_t PwmDutyCycleA)
  {
    PwmOutA = PwmDutyCycleA;
  }

void OutBset(uint8_t PwmDutyCycleB)
  {
    PwmOutB = PwmDutyCycleB;
  }

//-----------------------------------------------------------------------------
// SiLabs_Startup() Routine
// ----------------------------------------------------------------------------
// This function is called immediately after reset, before the initialization
// code is run in SILABS_STARTUP.A51 (which runs before main() ). This is a
// useful place to disable the watchdog timer, which is enable by default
// and may trigger before main() in some instances.
//-----------------------------------------------------------------------------
void SiLabs_Startup (void)
{
   PCA0MD &= ~0x40;                    // Disable Watchdog Timer
}
 
//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------

void main (void)
{
  uint8_t BarrelShift = 0;
  uint16_t TempPermilles = 1000;
  SFRPAGE = LEGACY_PAGE;              // Set for PCA0MD
  memset(CanMsgObject, 0, sizeof(CanMsgObject));


   OSCILLATOR_Init ();                 // Initialize oscillator
   PORT_Init ();                       // Initialize crossbar and GPIO
   ADC_Init();
   TIMER0_Init ();                     // Initialize Timer 0


   CANinit();                       // Start CAN peripheral

   CAN_RXTX_COMPLETE.u32 = 0x0000;       // Initialize as no messages transmitted

   EIE2 |= 0x02;                       // Enable CAN interrupts
   IE_EA = 1;                          // Enable global interrupts

   // The CAN0 ISR will handle any received messages

   // The Timer0 ISR will periodically poll and transmit a message

   // Example Application

   // StartAllNodes


   DataArray[0] = Segment;
   DataArray[1] = Red;
   DataArray[2] = Green;
   DataArray[3] = Blue;


   while (1)
     {
       IE_EA = 0;                          // Disable global interrupts keeps following Section Thread-safe
       DebugInput = CANgetMessageInt(GET_DEBUG_IN, 0);

       Battery1SoC  =  CANgetMessageInt(GET_BAT1_STATE, 4);
       Battery2SoC  =  CANgetMessageInt(GET_BAT2_STATE, 4);
       Battery3SoC  =  CANgetMessageInt(GET_BAT3_STATE, 4);
       Battery4SoC  =  CANgetMessageInt(GET_BAT4_STATE, 4);

       Battery1SoH  =  CANgetMessageInt(GET_BAT1_STATE, 6);
       Battery2SoH  =  CANgetMessageInt(GET_BAT2_STATE, 6);
       Battery3SoH  =  CANgetMessageInt(GET_BAT3_STATE, 6);
       Battery4SoH  =  CANgetMessageInt(GET_BAT4_STATE, 6);

       Battery1CellDiff_mV  =  CANgetMessageInt(GET_BAT1_CURRENT, 0);
       Battery2CellDiff_mV  =  CANgetMessageInt(GET_BAT2_CURRENT, 0);
       Battery3CellDiff_mV  =  CANgetMessageInt(GET_BAT3_CURRENT, 0);
       Battery4CellDiff_mV  =  CANgetMessageInt(GET_BAT4_CURRENT, 0);

       Battery1Current  =  CANgetMessageInt(GET_BAT1_CURRENT, 2);
       Battery2Current  =  CANgetMessageInt(GET_BAT2_CURRENT, 2);
       Battery3Current  =  CANgetMessageInt(GET_BAT3_CURRENT, 2);
       Battery4Current  =  CANgetMessageInt(GET_BAT4_CURRENT, 2);

       Battery1MaxChargeCurrent  =  CANgetMessageInt(GET_BAT1_CURRENT, 4);
       Battery2MaxChargeCurrent  =  CANgetMessageInt(GET_BAT2_CURRENT, 4);
       Battery3MaxChargeCurrent  =  CANgetMessageInt(GET_BAT3_CURRENT, 4);
       Battery4MaxChargeCurrent  =  CANgetMessageInt(GET_BAT4_CURRENT, 4);

       IsoImcRiso_kOhm  =  CANgetMessageInt(GET_IMD_INFO, 0);
       IsoImcStatus     =  CANgetMessageInt(GET_IMD_INFO, 2);
       IsoVifcStatus    =  CANgetMessageInt(GET_IMD_INFO, 4);

       TempPayload = CANgetMessageObjPayload(GET_INV_STATE1);
       InvInverter1Temp         = TempPayload.u8[0];
       InvMotor1Temp            = TempPayload.u8[1];
       InvMotor1Torque.u8[1]    = TempPayload.u8[2];
       InvMotor1Torque.u8[0]    = TempPayload.u8[3];
       InvMotorsFlags.u8[1]     = TempPayload.u8[4];
       InvMotorsFlags.u8[0]     = TempPayload.u8[5];
       InvSystemFlags.u8[1]     = TempPayload.u8[6];
       InvSystemFlags.u8[0]     = TempPayload.u8[7];

       TempPayload = CANgetMessageObjPayload(GET_INV_STATE2);
       InvTimeToService_h.u8[1] = TempPayload.u8[0];
       InvTimeToService_h.u8[0] = TempPayload.u8[1];
       InvTimeToService_min     = TempPayload.u8[2];
       InvTimeToService_s       = TempPayload.u8[3];
       InvFaultCode             = TempPayload.u8[4];
       InvFaultLevel            = TempPayload.u8[5];
       InvDcBusCurrent_dA.u8[1] = TempPayload.u8[6];
       InvDcBusCurrent_dA.u8[0] = TempPayload.u8[7];

       LastBroadcastMsg = CANgetMessageObjPayload(GET_BROADCAST);
       IE_EA = 1;                          // Enable global interrupts
//       BatterySoC  =   (Battery1SoC + Battery2SoC + Battery3SoC + Battery4SoC);
//       BarrelShift =   ((NumOfBat-1) > 3) ? 16 : NumOfBat-1;
//       BatterySoC = BatterySoC >> BarrelShift;
//       BatterySoC  =   (Battery1SoC + Battery2SoC + Battery3SoC + Battery4SoC)>>(((NumOfBat-1) > 3) ? 16 : NumOfBat-1);


//       BatterySoC  =   (Battery1SoC + Battery2SoC + Battery3SoC + Battery4SoC)/(uint16_t)((NumOfBat) ? NumOfBat : 1);


//       BatterySoH  =   (Battery1SoH + Battery2SoH + Battery3SoH + Battery4SoH)/(uint16_t)((NumOfBat) ? NumOfBat : 1);

       BatterySoC  =   (Battery1SoC + Battery2SoC + Battery3SoC + Battery4SoC)/((PeakNumOfBat) ? PeakNumOfBat : 1);
       BatterySoH  =   (Battery1SoH + Battery2SoH + Battery3SoH + Battery4SoH)/((PeakNumOfBat) ? PeakNumOfBat : 1);



       LED = DebugInput;

       if (AccessI2C(I2C_Channel_Slave, 240, 4, &DataArray, 5, &DataArray, I2C_MODE_MULTIPLE_START) != I2C_PRESENT) // RCC Connected
       {
/*
           TempPermilles = TempToPermilleScaleConverter((int8_t)-50);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           TempPermilles = TempToPermilleScaleConverter((int8_t)-30);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           TempPermilles = TempToPermilleScaleConverter((int8_t)0);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           TempPermilles = TempToPermilleScaleConverter((int8_t)-20);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           TempPermilles = TempToPermilleScaleConverter((int8_t)+20);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           TempPermilles = TempToPermilleScaleConverter((int8_t)+119);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           TempPermilles = TempToPermilleScaleConverter((int8_t)+126);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           TempPermilles = TempToPermilleScaleConverter((int8_t)+127);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempPermilles), MIN_RES, MAX_RES, 1);
*/

           SetGaugeSmooth(CHANNEL_GAUGE_A, GaugeScaleConverter(BatterySoC), MIN_RES, MAX_RES, 1); // Fuel Gauge showning Bettery Capacity
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(TempToPermilleScaleConverter((InvMotor1Temp > InvInverter1Temp) ? InvMotor1Temp : InvInverter1Temp)), MIN_RES, MAX_RES, 1); // the higher of both temperatures -> no ice warning!
           //SetGaugeHiRes(CHANNEL_GAUGE_B, GaugeScaleConverter(BatterySoH), MIN_RES, MAX_RES, 1); // use on prototype with different shunt and higher resolution for lower currents
           OutAset((IsoImcStatus)? 0xff : 0x00);
           OutBset((BatterySoC <= FUEL_WARN_LEVEL) ? 0xff : 0x00);
       }
       else
       {
           Notch = DataArray[0] - 1;
           ButtonState = DataArray[1];
           Angle = DataArray[3];

           OutAset(Angle);
           OutBset((ButtonState)? 0x00: 0xff);
           if (ButtonState)
           {
             Permillage = ((float)(Angle / 255.0F)) * 1000.0F;
             DataArray[0] = Segment;
             DataArray[1] = Angle;
             DataArray[2] = Angle;
             DataArray[3] = Angle;
           }
           else
           {
             Permillage = 52.64F * Notch;
             DataArray[0] = Segment;
             DataArray[1] = RedLine[Notch];
             DataArray[2] = GreenLine[Notch];
             DataArray[3] = BlueLine[Notch];
           }
           SetGaugeSmooth(CHANNEL_GAUGE_A, GaugeScaleConverter(Permillage), MIN_RES, MAX_RES, 1);
           SetGaugeSmooth(CHANNEL_GAUGE_B, GaugeScaleConverter(Permillage), MIN_RES, MAX_RES, 1);
         }
     }
}

//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// OSCILLATOR_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Initialize the internal oscillator to 24 MHz
//
//-----------------------------------------------------------------------------
void OSCILLATOR_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = CONFIG_PAGE;

   OSCICN = 0x87;                      // Set internal oscillator divider to 1

   SFRPAGE = SFRPAGE_save;
}



//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This function configures the crossbar and ports pins.
//
// P0.6   digital  push-pull        CAN TX
// P0.7   digital  open-drain       CAN RX
//
//
//-----------------------------------------------------------------------------
void PORT_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE  = CONFIG_PAGE;             // Port SFR's on Configuration page

   P1MDIN    = 0x0D;
   P2MDIN    = 0xFE;
   P0MDOUT   = 0x41;
   P1MDOUT   = 0x0D;
   P0SKIP    = 0x01;
   P1SKIP    = 0xFE;
   P2SKIP    = 0x01;
   XBR0      = 0x02;
   XBR2      = 0x40;
   SFRPAGE   = SFRPAGE_save;
}



//-----------------------------------------------------------------------------
// TIMER0_Init
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:    None
//
// Configure Timer0 to 16-bit Timer mode and generate an interrupt
// every TIMER0_RL Timer0 cycles using SYSCLK/48 as the Timer0 time base.
//
//-----------------------------------------------------------------------------
void TIMER0_Init(void)
{
   // No need to set SFRPAGE as all registers accessed in this function
   // are available on all pages

   TH0 = TIMER0_RL_HIGH;               // Init Timer0 High register
   TL0 = TIMER0_RL_LOW;                // Init Timer0 Low register

   TMOD  = 0x01;                       // Timer0 in 16-bit mode
   CKCON = 0x02;                       // Timer0 uses a 1:48 prescaler
   IE_ET0 = 1;                         // Timer0 interrupt enabled
   TCON  = 0x10;                       // Timer0 ON
}

//-----------------------------------------------------------------------------
// CANinit
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This function initializes the CAN peripheral and message objects
//
// CAN Bit Clock : 500kbps
// Auto Retransmit : Automatic Retransmission is enabled
// MsgVal        : Set to Valid based on the #define MESSAGE_OBJECTS
// Filtering     : Enabled for all valid message objects
// Message Identifier : 11-bit standard; Each message object is only used by
//                      one message ID
// Direction     : One buffer each is configured for transmit and receive
// End of Buffer : All message objects are treated as separate buffers
//
// The following interrupts are enabled and are handled by CAN0_ISR
//
// Error Interrupts
// Status Change Interrupt
// Receive Interrupt
// Transmit Interrupt
//-----------------------------------------------------------------------------
void CANinit (void)
{
   uint8_t i;

   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE  = CAN0_PAGE;               // All CAN register are on page 0x0C

   CAN0CN |= 0x01;                     // Start Initialization mode

   //---------Initialize general CAN peripheral settings

   CAN0CN |= 0x4E;                     // Enable Error and Module Interrupts
                                       // Enable access to bit timing register

   // See the CAN Bit Timing Spreadsheet for how to calculate this value
   CAN0BT = 0x1C02;                    // Based on 24 MHz CAN clock, set the
                                       // CAN bit rate to 500kbps

 
   //---------Initialize settings common to all message objects

   // Command Mask Register
   CAN0IF1CM = 0x00F0;                 // Write Operation
                                       // Transfer ID Mask, MDir, MXtd
                                       // Transfer ID, Dir, Xtd, MsgVal
                                       // Transfer Control Bits
                                       // Don't set TxRqst or transfer data

   // Mask Registers
   CAN0IF1M1 = 0x0000;                 // Mask Bits 15-0 not used for filtering
   CAN0IF1M2 = 0x5FFC;                 // Ignore Extended Identifier for
                                       // filtering
                                       // Used Direction bit for filtering
                                       // Use ID bits 28-18 for filtering
                                       
   // Arbitration Registers
   CAN0IF1A1 = 0x0000;                 // 11-bit ID, so lower 16-bits not used


   //---------Initialize settings for each valid message object

   for (i = 0; i < MESSAGE_OBJECTS; i++) // 0 denotes MsgObject 32!
   {

       if (MessageBoxInUse[i])
         {
           if (MessageBoxDirTx[i])
            {
              // Message Control Registers
    //          CAN0IF1MC = 0x0880 | MessageBoxSize[i];  // Enable Transmit Interrupt
              CAN0IF1MC = 0x0080 | MessageBoxSize[i];  // Disable Transmit Interrupt
                                                  // Message Object is a Single Message
                                                  // Message Size set by #define

              CAN0IF1A2 = 0xA000 | (MessageBoxCanId[i] << 2);  // Set MsgVal to valid
                                               // Set Direction to write
                                               // Set 11-bit Identifier
            }
          else
            {
              CAN0IF1MC = 0x1480 | MessageBoxSize[i];  // Enable Receive Interrupt
                                                  // Message Object is a Single Message
                                                  // Message Size set by #define

              // Arbitration Registers
              CAN0IF1A2 = 0x8000 | (MessageBoxCanId[i] << 2);  // Set MsgVal to valid
                                                     // Set Object Direction to read
                                                     // Set 11-bit Identifier
            }
         }
       else
         {
           // Set remaining message objects to be Ignored
           CAN0IF1A2 = 0x0000;              // Set MsgVal to 0 to Ignore
           CAN0IF1CR = i;                // Start command request

         }
      CAN0IF1CR = i;                // Start command request
      while (CAN0IF1CRH & 0x80);       // Poll on Busy bit
   }
   //--------- CAN initialization is complete

   CAN0CN &= ~0x41;                    // Return to Normal Mode and disable
                                       // access to bit timing register

   EIE2 |= 0x02;                       // Enable CAN interrupts

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// ADC0_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure ADC0 to use ADBUSY as conversion source.
// Disables ADC end of conversion interrupt. Leaves ADC
// disabled.
//
//-----------------------------------------------------------------------------

void ADC_Init (void)
{
   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE = LEGACY_PAGE;

   ADC0CN = 0x00;                      // ADC0 disabled; Burst mode disabled
                                       // Data is right-justified
                                       // ADC0 conversions are initiated
                                       // on a write to AD0Busy

   ADC0CF = (SYSCLK/3000000) << 3;     // ADC conversion clock <= 3MHz
                                       // Repeat Count = 1
   REF0CN    = 0x1B;
//   REF0CN    = 0x38;
//   REF0CN = 0x17;                      // Enable on-chip VREF and buffer
                                       // Set voltage reference to 2.20V setting
                                       // Enable temperature sensor

   EIE1 &= ~0x04;                      // Disable ADC0 conversion interrupt

   ADC0CN_ADEN = 1;                          // Enable ADC0 (ADC0CN)

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// Supporting Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// CANsetupMessageObj
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : uint8_t obj_num - message object number to send data
//                             range is 0x01 - 0x20
//              : SI_UU64_t payload - CAN message to send (8 Bytes)
//
//
// Send data using the message object and payload passed as the parameters.
//
//-----------------------------------------------------------------------------
void CANsetupMessageObj(uint8_t objNum, uint16_t canId, uint8_t dirTx,  uint8_t len, SI_UU64_t payload)
{
     uint8_t SFRPAGE_save = SFRPAGE;
     SFRPAGE  = CAN0_PAGE;               // All CAN register are on page 0x0C

     // Deactivate MessageObject before modification can take place
     CAN0IF1A2 = 0x0000;              // Set MsgVal to 0 to Ignore
     CAN0IF1CR = objNum;              // Start command request
     while (CAN0IF1CRH & 0x80);       // Poll on Busy bit

     // Command Mask Register
     CAN0IF1CM = 0x00F0;                 // Write Operation
                                         // Transfer ID Mask, MDir, MXtd
                                         // Transfer ID, Dir, Xtd, MsgVal
                                         // Transfer Control Bits
                                         // Don't set TxRqst or transfer data

     // Mask Registers
     CAN0IF1M1 = 0x0000;                 // Mask Bits 15-0 not used for filtering
     CAN0IF1M2 = 0x5FFC;                 // Ignore Extended Identifier for
                                         // filtering
                                         // Used Direction bit for filtering
                                         // Use ID bits 28-18 for filtering

     // Arbitration Registers
     CAN0IF1A1 = 0x0000;                 // 11-bit ID, so lower 16-bits not used


     if (dirTx)
       {
         // Message Control Registers
 //        CAN0IF1MC = 0x0880 | len;  // Enable Transmit Interrupt
         CAN0IF1MC = 0x0080 | len;  // Disable Transmit Interrupt
                                            // Message Object is a Single Message
                                             // Message Size set by variable: len


         CAN0IF1A2 = 0xA000 | (canId << 2);  // Set MsgVal to valid

         CAN0IF1DA1L = payload.u8[0]; // Initialize data registers based
         CAN0IF1DA1H = payload.u8[1]; // on message object used
         CAN0IF1DA2L = payload.u8[2];
         CAN0IF1DA2H = payload.u8[3];
         CAN0IF1DB1L = payload.u8[4];
         CAN0IF1DB1H = payload.u8[5];
         CAN0IF1DB2L = payload.u8[6];
         CAN0IF1DB2H = payload.u8[7];
       }
     else
       {

         // Message Control Registers
         CAN0IF1MC = 0x1480 | len;  // Enable Receive Interrupt
                                             // Message Object is a Single Message
                                             // Message Size set by variable: len
         // Arbitration Registers
         CAN0IF1A2 = 0x8000 | (canId << 2);  // Set MsgVal to valid
                                             // Set 11-bit Identifier to iter
       }
     CAN0IF1CR = objNum;                // Start command request

     while (CAN0IF1CRH & 0x80);       // Poll on Busy bit

     // Message Control Registers
     CAN0IF1MC = 0x0080 | len;  // Disable Transmit Interrupt
                                         // Message Object is a Single Message
                                         // Message Size set by #define
     // Arbitration Registers
     CAN0IF1A1 = 0x0000;                 // 11-bit ID, so lower 16-bits not used

     // Arbitration Registers
     CAN0IF1A2 = 0xA000 | (canId << 2);  // Set MsgVal to valid
                                            // Set Direction to write
                                            // Set 11-bit Identifier to iter

     CAN0IF1CR = objNum;            // Start command request

     while (CAN0IF1CRH & 0x80);        // Poll on Busy bit
     SFRPAGE = SFRPAGE_save;
}


//-----------------------------------------------------------------------------
// CANtransferMessageObj
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : uint8_t obj_num - message object number to send data
//                             range is 0x01 - 0x20
//              : SI_UU64_t payload - CAN message to send (8 Bytes)
//
// Send data using the message object and payload passed as the parameters.
//
//-----------------------------------------------------------------------------

void CANtransferMessageObj(uint8_t objNum, SI_UU64_t payload)
{

   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE  = CAN0_PAGE;               // All CAN register are on page 0x0C

   // Initialize all 8 data bytes even though they might not be sent
   // The number to send was configured earlier by setting Message Control

   CAN0IF1DA1L = payload.u8[0]; // Initialize data registers based
   CAN0IF1DA1H = payload.u8[1]; // on message object used
   CAN0IF1DA2L = payload.u8[2];
   CAN0IF1DA2H = payload.u8[3];
   CAN0IF1DB1L = payload.u8[4];
   CAN0IF1DB1H = payload.u8[5];
   CAN0IF1DB2L = payload.u8[6];
   CAN0IF1DB2H = payload.u8[7];

   CAN0IF1CM = 0x0087;                 // Set Direction to Write
                                       // Write TxRqst, all 8 data bytes
                                       // (chapter 4.4 Bosch C_CAN)

   CAN0IF1CR = objNum;                // Start command request

   while (CAN0IF1CRH & 0x80);          // Poll on Busy bit

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// CANtriggerMessageObj
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : uint8_t obj_num - message object number to send data
//                             range is 0x01 - 0x20
///
// Send data using the message object and payload passed while init phase.
//
//-----------------------------------------------------------------------------

void CANtriggerMessageObj(uint8_t objNum)
{

   uint8_t SFRPAGE_save = SFRPAGE;
   SFRPAGE  = CAN0_PAGE;               // All CAN register are on page 0x0C

   CAN0IF1CR = objNum;                // Start command request

   while (CAN0IF1CRH & 0x80);          // Poll on Busy bit

   SFRPAGE = SFRPAGE_save;
}


//-----------------------------------------------------------------------------
// CANgetMessageObjPayload
//-----------------------------------------------------------------------------
//
// Return Value : SI_UU64_t payload -Full CAN-Message
// Parameters   : uint8_t objNum - message object number to read data from
//                             range is 0x01 - 0x20
//
// Provides an atomic section for the consistent access to a specific payload
//
//-----------------------------------------------------------------------------

SI_UU64_t CANgetMessageObjPayload(uint8_t objNum)
{
  SI_UU64_t payload;
  uint8_t intStatSave = IE_EA;         // Preserve state of global Interrupts

  IE_EA = 0;                            // Disable global interrupts
//  EIE2 &= ~0x02;                      // Disable CAN interrupts
  payload = CanMsgObject[objNum];
//  EIE2 |= 0x02;                       // Enable CAN interrupts
  IE_EA = intStatSave;                 // restore global interrupts

  return payload;
}



//-----------------------------------------------------------------------------
// CANgetMessageInt
//-----------------------------------------------------------------------------
//
// Return Value : int16_t
// Parameters   : uint8_t objNum - message object number to read data from
//                             range is 0x01 - 0x20
//                uint8_t startIndex - index where to start conversion from
//
// Provides an atomic section for the consistent access to a specific signed word
//
//-----------------------------------------------------------------------------

int16_t CANgetMessageInt(uint8_t objNum, uint8_t startIndex)
{
  SI_UU64_t payload;
  SI_UU16_t result;
  uint8_t intStatSave = IE_EA;         // Preserve state of global Interrupts

  IE_EA = 0;                            // Disable global interrupts
//  EIE2 &= ~0x02;                      // Disable CAN interrupts
  payload = CanMsgObject[objNum];
//  EIE2 |= 0x02;                       // Enable CAN interrupts
  IE_EA = intStatSave;                 // restore global interrupts
  result.u8[0] = payload.u8[startIndex+1];
  result.u8[1] = payload.u8[startIndex];
  return result.s16;
}

//returns the DAC0 reading of the given pin(HEX)
uint16_t getAdcReading(uint8_t pin)
{
  uint16_t currval;                        // Current value of ADC0

  uint8_t SFRPAGE_save = SFRPAGE;
  SFRPAGE = LEGACY_PAGE;

  ADC0MX = pin;

  ADC0CN_ADINT = 0;                         // Clear end-of-conversion indicator
  ADC0CN_ADBUSY = 1;                        // Initiate conversion

  while (!ADC0CN_ADINT);                 // Wait for conversion to complete
  ADC0CN_ADINT = 0;                      // Clear end-of-conversion indicator

  currval = ADC0;                  // Store latest ADC conversion
  ADC0CN_ADBUSY = 1;                     // Initiate conversion

  SFRPAGE = SFRPAGE_save;
  return currval;
}
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Interrupt Service Routines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// TIMER0_ISR
//-----------------------------------------------------------------------------
//
// The ISR is triggered upon any CAN errors or upon a message reception
//
// If an error occurs, a global counter is updated
//
//-----------------------------------------------------------------------------

SI_INTERRUPT(TIMER0_ISR, TIMER0_IRQn)
{
   // Timer0 ISR pending flag is automatically cleared by vectoring to ISR

  static uint8_t step = 0;
  SI_UU64_t DataBaguette;                // TempData to define CAN-Messages
  static uint16_t FirstRun = STARTUP_DELAY; //Skip at startup
  static uint8_t NumOfBat = 0;

  uint8_t TestBat1 = 0;
  uint8_t TestBat2 = 0;
  uint8_t TestBat3 = 0;
  uint8_t TestBat4 = 0;

#if (SEND_DBG_COUNTER == 1)
  static uint16_t DbgCounter = 0;

  DataBaguette.u16[0] = DbgCounter;
  DataBaguette.u8[0] ^= DataBaguette.u8[1];    // Swap Bytes by XORing Step1
  DataBaguette.u8[1] ^= DataBaguette.u8[0];    // Swap Bytes by XORing Step2
  DataBaguette.u8[0] ^= DataBaguette.u8[1];    // Swap Bytes by XORing Step3
  CANtransferMessageObj(SET_DEBUG_OUT, DataBaguette);
  CANtriggerMessageObj(SET_DEBUG_OUT);         // Send the prepared Message-Objects to the CAN-Bus
  DbgCounter++;
#endif

  OUT_A = (PwmOutA <= step) ?  0 : 1;
  OUT_B = (PwmOutB <= step) ?  0 : 1;
  step = (step == 0xfe) ? 0x00 : step + 1; // allow for 0%...100% Dutycycle, so step 255 is locked out


  if (FirstRun)
    {
      //comment this line if other client sends <reset all nodes>
      if (FirstRun == STARTUP_DELAY) // Do this only once before startup
        {
          DataBaguette.u8[0] = 0x00;    // Prepare CAN-Message <Reset all Nodes>
          DataBaguette.u8[1] = 0x81;
          CANtransferMessageObj(SET_BROADCAST, DataBaguette);
          CANtriggerMessageObj(SET_BROADCAST);      // Send the prepared Message-Objects to the CAN-Bus
      }


      if (FirstRun == (STARTUP_DELAY >> 2)) // Do this only once during startup
      {
          DataBaguette.u8[0] = 0x01;    // Prepare Message <Start All Nodes>
          DataBaguette.u8[1] = 0x00;
          CANtransferMessageObj(SET_BROADCAST, DataBaguette);
          CANtriggerMessageObj(SET_BROADCAST);      // Send the prepared Message-Objects to the CAN-Bus
      }


      if (FirstRun == 1) // Do this only once after startup
      {
          DataBaguette.u8[0] = 0x00;    // Prepare CAN-Message <Startup>
          CANtransferMessageObj(SET_HEARTBEAT, DataBaguette);
          CANtriggerMessageObj(SET_HEARTBEAT);      // Send the prepared Message-Objects to the CAN-Bus
      }

      FirstRun--;
    }
  else
    {
#if (SEND_HEARTBEAT == 1)
      DataBaguette.u8[0] = 0x05;    // Prepare CAN-Message <Heartbeat>
      CANtransferMessageObj(SET_HEARTBEAT, DataBaguette);
      CANtriggerMessageObj(SET_HEARTBEAT);      // Send the prepared Message-Objects to the CAN-Bus
#endif

    }

  // Count the number of batteries after <first-run> phase
  TestBat1 = CANgetMessageInt(GET_BAT1_STATE, 0) & 0x01;
  TestBat2 = CANgetMessageInt(GET_BAT2_STATE, 0) & 0x01;
  TestBat3 = CANgetMessageInt(GET_BAT3_STATE, 0) & 0x01;
  TestBat4 = CANgetMessageInt(GET_BAT4_STATE, 0) & 0x01;
  NumOfBat = TestBat1 + TestBat2 + TestBat3 + TestBat4;
  PeakNumOfBat = (NumOfBat > PeakNumOfBat) ? NumOfBat : PeakNumOfBat;

  DataBaguette.u32[0] = 0x00000000;
  DataBaguette.u32[1] = 0x00000000;

# if (NUM_OF_BATTERIES != 0)
    NumOfBat = NUM_OF_BATTERIES;
# endif
  if ((CANgetMessageInt(GET_BAT1_STATE, 0) & BMS_STATE_VALID_VALUES) +
      (CANgetMessageInt(GET_BAT2_STATE, 0) & BMS_STATE_VALID_VALUES) +
      (CANgetMessageInt(GET_BAT3_STATE, 0) & BMS_STATE_VALID_VALUES) +
      (CANgetMessageInt(GET_BAT4_STATE, 0) & BMS_STATE_VALID_VALUES) ==
      (BMS_STATE_VALID_VALUES * NumOfBat)) // Dynamic Num of Bat
    {
      LED = 0; //LED ON and Batteries ON
      DataBaguette.u8[0] = BAT_ON;
    }
  else
    {
      LED = 1; //LED OFF and all Batteries OFF
      DataBaguette.u8[0] = BAT_OFF;
    }

  if (TestBat1)
    {
      CANtransferMessageObj(SET_BAT1_STATE, DataBaguette);
      CANtriggerMessageObj(SET_BAT1_STATE);
    }

  if (TestBat2)
    {
      CANtransferMessageObj(SET_BAT2_STATE, DataBaguette);
      CANtriggerMessageObj(SET_BAT2_STATE);
    }

  if (TestBat3)
    {
      CANtransferMessageObj(SET_BAT3_STATE, DataBaguette);
      CANtriggerMessageObj(SET_BAT3_STATE);
    }

  if (TestBat4)
    {
      CANtransferMessageObj(SET_BAT4_STATE, DataBaguette);
      CANtriggerMessageObj(SET_BAT4_STATE);
    }
}


//-----------------------------------------------------------------------------
// CAN0_ISR
//-----------------------------------------------------------------------------
//
// The ISR is triggered upon any CAN errors or upon a complete transmission
//
// If an error occurs, a global counter is updated
//
//-----------------------------------------------------------------------------

SI_INTERRUPT(CAN0_ISR, CAN0_IRQn)
{
   // SFRPAGE is set to CAN0_Page automatically when ISR starts

   uint8_t status = CAN0STAT;          // Read status, which clears the Status
                                       // Interrupt bit pending in CAN0IID

   uint8_t Interrupt_ID = CAN0IID;     // Read which message object caused
                                       // the interrupt

   CAN0IF1CM = 0x007F;                 // Read all of message object to IF1
                                       // Clear IntPnd and newData


   CAN0IF1CR = Interrupt_ID;           // Start command request to actually
                                       // clear the interrupt

   // Message Object 0 reports as 0x20 in the CAN0IID register, so
   // convert it to 0x00
   if (Interrupt_ID == 0x20)
   {
      Interrupt_ID = 0x00;
   }


   while (CAN0IF1CRH & 0x80) {}        // Poll on Busy bit

   if (status & (TxOk | RxOk))                  // If transmit completed successfully
   {
      // Set variable to indicate this message object's transfer completed


      // Bit-shifting doesn't work with an operator greater than 15, so
      // account for it
      if (Interrupt_ID <= 15)
      {
	      CAN_RXTX_COMPLETE.u32 |= (uint16_t) (0x01 << Interrupt_ID);
      }
      else if (Interrupt_ID <= 0x1F)
      {
         CAN_RXTX_COMPLETE.u16[MSB] |= (uint16_t) (0x01 << (Interrupt_ID - 16));
      }
   }

   //if ((status & RxOk) && (Interrupt_ID != 0))

   if (status & RxOk)                  // If transmit completed successfully
   {
       // Read all 8 data bytes to rxdata, even though they might not be valid

       CanMsgObject[Interrupt_ID].u8[0] = CAN0IF1DA1L;    // First pair of bytes
       CanMsgObject[Interrupt_ID].u8[1] = CAN0IF1DA1H;    // First pair of bytes
       CanMsgObject[Interrupt_ID].u8[2] = CAN0IF1DA2L;    // Second pair of bytes
       CanMsgObject[Interrupt_ID].u8[3] = CAN0IF1DA2H;    // Second pair of bytes
       CanMsgObject[Interrupt_ID].u8[4] = CAN0IF1DB1L;    // Third pair of bytes
       CanMsgObject[Interrupt_ID].u8[5] = CAN0IF1DB1H;    // Third pair of bytes
       CanMsgObject[Interrupt_ID].u8[6] = CAN0IF1DB2L;    // Fourth and last pair of bytes
       CanMsgObject[Interrupt_ID].u8[7] = CAN0IF1DB2H;    // Fourth and last pair of bytes
       CanMsgId[Interrupt_ID] = CAN0IF1A2;

   }




   // If an error occurred, simply update the global variable and continue
   if (status & LEC)
   {
       // The LEC bits identify the type of error, but those are grouped here
      if ((status & LEC) != 0x07)
      {
          CAN_ERROR = 1;
      }
   }

   if (status & BOff)
   {
      CAN_ERROR = 1;
   }

   if (status & EWarn)
   {
      CAN_ERROR = 1;
   }

   // Old SFRPAGE is popped off the SFR stack when ISR exits
}

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------

