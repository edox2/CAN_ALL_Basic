/*
 * HalDef.c
 *
 *  Created on: 12.07.2016
 *********************************************
 *      (c)2016 SIGITRONIC SOFTWARE          *
 *                                           *
 *      Author: Matthias Siegenthaler        *
 *                                           *
 *        matthias@sigitronic.com            *
 *********************************************
 */
#include "HalDef.h"
#include <SI_C8051F550_Defs.h>
#include <SI_C8051F550_Register_Enums.h>
#include "si_toolchain.h"

//#include <reg51.h>

volatile uint32_t x;



void CountDelay(uint32_t count) {
	for (x = 0; x < count; x)
		x++;
}

