/*
 * HalDef.h
 *
 *  Created on: 19.05.2021
 *********************************************
 *      (c)2021 SIGITRONIC SOFTWARE          *
 *                                           *
 *      Author: Matthias Siegenthaler        *
 *                                           *
 *        matthias@sigitronic.com            *
 *********************************************
 */

#ifndef HALDEF_H_
#define HALDEF_H_

#include <SI_C8051F550_Defs.h>
#include <SI_C8051F550_Register_Enums.h>
#include "si_toolchain.h"

SI_SBIT(LED, SFR_P0, 0);                 // LED = 0 turns on the green LED
SI_SBIT(OUT_A, SFR_P1, 2);               // 1 = Enable Out_A, 0=Disable Out_A
SI_SBIT(OUT_B, SFR_P1, 3);               // 1 = Enable Out_A, 0=Disable Out_A
#define I2C_Channel_Monitor (0)
#define I2C_Channel_Slave (1)
SI_SBIT(I2C_SDA_Ch3, SFR_P0, 4); // RCC/DUT (MIRRORED)
SI_SBIT(I2C_SCL_Ch3, SFR_P0, 5); // RCC/DUT (MIRRORED)
SI_SBIT(I2C_SDA_Ch2, SFR_P0, 1); // INA219  (MIRRORED)
SI_SBIT(I2C_SCL_Ch2, SFR_P0, 2); // INA219  (MIRRORED)
SI_SBIT(I2C_SDA_Ch1, SFR_P0, 4); // RCC/DUT
SI_SBIT(I2C_SCL_Ch1, SFR_P0, 5); // RCC/DUT
SI_SBIT(I2C_SDA_Ch0, SFR_P0, 1); // INA219
SI_SBIT(I2C_SCL_Ch0, SFR_P0, 2); // INA219

// Counter Delay Loops
/*******************************************/
#define DelayTime4I2C	(1)
#define DelayIteration4I2C	(10)
//Base-Addresses for I2C Devices
/*******************************************/

void CountDelay(uint32_t count);

#endif /* HALDEF_H_ */
